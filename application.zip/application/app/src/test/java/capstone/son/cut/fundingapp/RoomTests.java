package capstone.son.cut.fundingapp;

import android.content.Context;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import androidx.room.Room;
import capstone.son.cut.fundingapp.AppDatabase;

public class RoomTests {

    @Test
    public void getRoom(){
        Instrum
        Context context = InstrumentationRegistry
        ContextInjectionFactory.make
        AppDatabase.getInstance(get).RoomUserDao().insertUser()
    }



    }

