package capstone.son.cut.fundingapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
@Dao
public interface RoomUserDao {
    @Query("select * from roomuser")
    List<User> getAll();

    @Query("select * from roomuser where user_id in (user_id)")
    List<User> loadAllByIds(int[] userIds);

    @Query("select * from roomuser where user_id in (password)")
    User findByName(String first, String last);
    @Insert
    void insertAll(User... users);
    @Delete
    void delete(User user);

}
//    public User get(Long id) throws ClassNotFoundException, SQLException {
//        Connection connection = getConnection();
//        // 쿼리만들고
//        PreparedStatement preparedStatement = connection.prepareStatement("select * from userinfo where id = ?");
//        preparedStatement.setLong(1, id);
//        // 실행
//        ResultSet resultSet = preparedStatement.executeQuery();
//        resultSet.next();
//        // 결과매핑
//        User user = new User();
//        user.setId(resultSet.getLong("id"));
//        user.setName(resultSet.getString("name"));
//        user.setPassword(resultSet.getString("password"));
//
//        //자원을 해지한다.
//        resultSet.close();
//        preparedStatement.close();
//        connection.close();
//
//        return user;
//    }
//
//    private Connection getConnection() throws ClassNotFoundException, SQLException {
//        //데이터는어디에?   Mysql
//        //Driver Class Load
//        Class.forName("com.mysql.cj.jdbc.Driver");
//        // Connection    접속정보는? localhost jeju id : jeju pw: jejupw
//        return DriverManager.getConnection("jdbc:mysql://localhost/?serverTimezone=UTC", "root", "");
//    }



